package com.example.nathan.ex2nac;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import org.json.JSONObject;
import org.json.JSONException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void smt(View view){

        TextView id = findViewById(R.id.id);
        TextView tit = findViewById(R.id.tit);
        TextView body = findViewById(R.id.body);
        TextView result = findViewById(R.id.result);

        String url = "https://jsonplaceholder.typicode.com/posts";

        String parameter =
                "{\n  "                                       +
                        "   \"userId\":   ValorId,\n  " +
                        "   \"title\" : \"ValorTitulo\"\n  " +
                        "   \"body\"  : \"ValorContex\"\n   " +
                        "}                                     ";


        parameter.replace( "ValorId" , id.getText().toString() );
        parameter.replace( "ValorTitulo" , tit.getText().toString() );
        parameter.replace( "ValorContex" , body.getText().toString() );

        new DataGetterPost(result).execute(url,parameter);
    }
}
