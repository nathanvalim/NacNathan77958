package com.example.nathan.ex1nac;


import android.os.AsyncTask;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

public class DataGetter extends AsyncTask<String,Void,String> {
    private TextView txtNome;
    private TextView txtSobrenome;

    public DataGetter(TextView txtNome, TextView txtSobrenome) {
        this.txtNome = txtNome;
        this.txtSobrenome = txtSobrenome;

    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected String doInBackground(String... strings) {

        String url = strings[0];
        String result = NetworkToolkit.doGet(url);


        return result;
    }

    @Override
    protected void onPostExecute(String s) {


        try{
            JSONObject jsonObject = new JSONObject(s);




            String firstName = jsonObject.getString("title");
            boolean lastName = jsonObject.getBoolean("completed");

            txtNome.setText(firstName);
            txtSobrenome.setText(toString().valueOf(lastName));

        }
        catch(JSONException e){
            this.txtNome.setText("erroJSON");
        }
    }
}
