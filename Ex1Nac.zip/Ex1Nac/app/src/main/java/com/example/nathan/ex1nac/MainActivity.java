package com.example.nathan.ex1nac;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void executaConsulta(View view){


        String response;
        EditText txtConsulta = findViewById(R.id.editTextPesquisa);
        TextView txtNome = findViewById(R.id.txtNome);
        TextView txtSobrenome = findViewById(R.id.txtSobrenome);

        String url = "https://jsonplaceholder.typicode.com/todos/" + txtConsulta.getText().toString();


        new DataGetter(txtNome,txtSobrenome).execute(url);

        txtConsulta.selectAll();

    }
}
