package com.example.nathan.ex3nac;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText tit;
    private EditText anot;
    private final String memory = "";
    private final String outMemory = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void busc(View view){

        tit = (EditText) findViewById(R.id.tit);
        anot = (EditText) findViewById(R.id.anot);


        String title = tit.getText().toString();


        SharedPreferences sh = getSharedPreferences(memory, Context.MODE_PRIVATE);


        String note = sh.getString(title, outMemory);

        if(note == outMemory) Toast.makeText(this, title+" não foi econtrada!", Toast.LENGTH_LONG).show();

        else {
            anot.setText(note);
            Toast.makeText(this, "Econtrada!", Toast.LENGTH_LONG).show();
        }
    }

    public void adic(View view) {

        tit = (EditText) findViewById(R.id.tit);
        anot = (EditText) findViewById(R.id.anot);

        String title = tit.getText().toString();
        String note = anot.getText().toString();


        SharedPreferences sh = getSharedPreferences(memory, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sh.edit();


        ed.putString(title, note);


        ed.apply();

        tit.setText("");
        anot.setText("");

        Toast.makeText(this, "Sua nota foi adicionada!", Toast.LENGTH_LONG).show();
    }
}
